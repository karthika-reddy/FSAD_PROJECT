import mysql from 'mysql2/promise';

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || 'karthikareddy1*',
  database: process.env.DB_NAME || 'student_management_system',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

export default pool;

export type Student = {
  id: number;
  student_id: string;
  first_name: string;
  last_name: string;
  email: string;
  phone: string | null;
  date_of_birth: string | null;
  gender: 'Male' | 'Female' | 'Other';
  address: string | null;
  city: string | null;
  state: string | null;
  zip_code: string | null;
  enrollment_date: string;
  status: 'Active' | 'Inactive' | 'Graduated' | 'Suspended';
  gpa: number;
  created_at: string;
  updated_at: string;
};

export type Course = {
  id: number;
  course_code: string;
  course_name: string;
  description: string | null;
  credits: number;
  department: string | null;
  instructor: string | null;
  max_capacity: number;
  current_enrollment: number;
  semester: 'Fall' | 'Spring' | 'Summer';
  year: number;
  status: 'Active' | 'Inactive' | 'Completed';
  created_at: string;
  updated_at: string;
};

export type Enrollment = {
  id: number;
  student_id: number;
  course_id: number;
  enrollment_date: string;
  grade: string | null;
  status: 'Enrolled' | 'Completed' | 'Dropped' | 'Withdrawn';
  attendance_percentage: number;
  created_at: string;
  updated_at: string;
  // Joined fields
  student_name?: string;
  course_name?: string;
  course_code?: string;
};

export type DashboardStats = {
  totalStudents: number;
  totalCourses: number;
  totalEnrollments: number;
  activeStudents: number;
  averageGpa: number;
  statusDistribution: { status: string; count: number }[];
  departmentDistribution: { department: string; count: number }[];
  recentEnrollments: Enrollment[];
};
