"use client";

import { cn } from "@/lib/utils";

type StatusType =
  | "Active"
  | "Inactive"
  | "Graduated"
  | "Suspended"
  | "Enrolled"
  | "Completed"
  | "Dropped"
  | "Withdrawn";

const statusStyles: Record<StatusType, string> = {
  Active: "bg-primary/20 text-primary border-primary/30",
  Inactive: "bg-muted text-muted-foreground border-muted",
  Graduated: "bg-chart-2/20 text-chart-2 border-chart-2/30",
  Suspended: "bg-destructive/20 text-destructive border-destructive/30",
  Enrolled: "bg-primary/20 text-primary border-primary/30",
  Completed: "bg-chart-2/20 text-chart-2 border-chart-2/30",
  Dropped: "bg-chart-3/20 text-chart-3 border-chart-3/30",
  Withdrawn: "bg-muted text-muted-foreground border-muted",
};

interface StatusBadgeProps {
  status: string;
  className?: string;
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const style = statusStyles[status as StatusType] || statusStyles.Inactive;

  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium",
        style,
        className
      )}
    >
      {status}
    </span>
  );
}
