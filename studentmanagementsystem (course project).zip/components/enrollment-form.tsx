"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Enrollment, Student, Course } from "@/lib/db";
import { Spinner } from "@/components/ui/spinner";

interface EnrollmentFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  enrollment?: Enrollment | null;
  onSuccess: () => void;
}

const GRADES = ["A+", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D+", "D", "D-", "F"];

export function EnrollmentForm({
  open,
  onOpenChange,
  enrollment,
  onSuccess,
}: EnrollmentFormProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [students, setStudents] = useState<Student[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [formData, setFormData] = useState({
    student_id: enrollment?.student_id?.toString() || "",
    course_id: enrollment?.course_id?.toString() || "",
    grade: enrollment?.grade || "",
    status: enrollment?.status || "Enrolled",
    attendance_percentage: enrollment?.attendance_percentage?.toString() || "0",
  });

  useEffect(() => {
    if (open) {
      // Fetch students and courses for the dropdowns
      fetch("/api/students?limit=100")
        .then((res) => res.json())
        .then((data) => setStudents(data.students || []))
        .catch(console.error);

      fetch("/api/courses?limit=100")
        .then((res) => res.json())
        .then((data) => setCourses(data.courses || []))
        .catch(console.error);
    }
  }, [open]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const url = enrollment
        ? `/api/enrollments/${enrollment.id}`
        : "/api/enrollments";
      const method = enrollment ? "PUT" : "POST";

      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...formData,
          student_id: parseInt(formData.student_id),
          course_id: parseInt(formData.course_id),
          attendance_percentage: parseFloat(formData.attendance_percentage) || 0,
          grade: formData.grade || null,
        }),
      });

      if (response.ok) {
        onSuccess();
        onOpenChange(false);
        // Reset form
        setFormData({
          student_id: "",
          course_id: "",
          grade: "",
          status: "Enrolled",
          attendance_percentage: "0",
        });
      } else {
        const error = await response.json();
        alert(error.error || "Failed to save enrollment");
      }
    } catch (error) {
      console.error("Error saving enrollment:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>
            {enrollment ? "Edit Enrollment" : "New Enrollment"}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="student_id">Student</Label>
            <Select
              value={formData.student_id}
              onValueChange={(value) =>
                setFormData({ ...formData, student_id: value })
              }
              disabled={!!enrollment}
            >
              <SelectTrigger id="student_id">
                <SelectValue placeholder="Select student" />
              </SelectTrigger>
              <SelectContent>
                {students.map((student) => (
                  <SelectItem key={student.id} value={student.id.toString()}>
                    {student.student_id} - {student.first_name} {student.last_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="course_id">Course</Label>
            <Select
              value={formData.course_id}
              onValueChange={(value) =>
                setFormData({ ...formData, course_id: value })
              }
              disabled={!!enrollment}
            >
              <SelectTrigger id="course_id">
                <SelectValue placeholder="Select course" />
              </SelectTrigger>
              <SelectContent>
                {courses.map((course) => (
                  <SelectItem key={course.id} value={course.id.toString()}>
                    {course.course_code} - {course.course_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid gap-4 grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="grade">Grade</Label>
              <Select
                value={formData.grade}
                onValueChange={(value) =>
                  setFormData({ ...formData, grade: value })
                }
              >
                <SelectTrigger id="grade">
                  <SelectValue placeholder="Select grade" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No Grade</SelectItem>
                  {GRADES.map((grade) => (
                    <SelectItem key={grade} value={grade}>
                      {grade}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value) =>
                  setFormData({ ...formData, status: value })
                }
              >
                <SelectTrigger id="status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Enrolled">Enrolled</SelectItem>
                  <SelectItem value="Completed">Completed</SelectItem>
                  <SelectItem value="Dropped">Dropped</SelectItem>
                  <SelectItem value="Withdrawn">Withdrawn</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="attendance_percentage">Attendance (%)</Label>
            <Input
              id="attendance_percentage"
              type="number"
              min="0"
              max="100"
              step="0.1"
              value={formData.attendance_percentage}
              onChange={(e) =>
                setFormData({ ...formData, attendance_percentage: e.target.value })
              }
            />
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading && <Spinner className="mr-2 h-4 w-4" />}
              {enrollment ? "Update Enrollment" : "Create Enrollment"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
