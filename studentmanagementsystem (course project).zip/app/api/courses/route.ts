import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/db';
import { RowDataPacket, ResultSetHeader } from 'mysql2';

// Mock courses data
const mockCourses = [
  { id: 1, course_code: 'CS101', course_name: 'Introduction to Programming', description: 'Fundamentals of programming using Python', credits: 3, department: 'Computer Science', instructor: 'Dr. Alan Turing', max_capacity: 40, current_enrollment: 38, semester: 'Fall', year: 2024, status: 'Active', created_at: '2024-01-01', updated_at: '2024-01-15' },
  { id: 2, course_code: 'CS201', course_name: 'Data Structures', description: 'Advanced data structures and algorithms', credits: 4, department: 'Computer Science', instructor: 'Dr. Ada Lovelace', max_capacity: 35, current_enrollment: 32, semester: 'Fall', year: 2024, status: 'Active', created_at: '2024-01-01', updated_at: '2024-01-15' },
  { id: 3, course_code: 'MATH101', course_name: 'Calculus I', description: 'Introduction to differential calculus', credits: 4, department: 'Mathematics', instructor: 'Dr. Isaac Newton', max_capacity: 50, current_enrollment: 48, semester: 'Fall', year: 2024, status: 'Active', created_at: '2024-01-01', updated_at: '2024-01-15' },
  { id: 4, course_code: 'MATH201', course_name: 'Calculus II', description: 'Integral calculus and series', credits: 4, department: 'Mathematics', instructor: 'Dr. Gottfried Leibniz', max_capacity: 45, current_enrollment: 40, semester: 'Fall', year: 2024, status: 'Active', created_at: '2024-01-01', updated_at: '2024-01-15' },
  { id: 5, course_code: 'PHY101', course_name: 'Physics I', description: 'Mechanics and thermodynamics', credits: 4, department: 'Physics', instructor: 'Dr. Albert Einstein', max_capacity: 40, current_enrollment: 35, semester: 'Fall', year: 2024, status: 'Active', created_at: '2024-01-01', updated_at: '2024-01-15' },
  { id: 6, course_code: 'CHEM101', course_name: 'General Chemistry', description: 'Introduction to chemistry principles', credits: 4, department: 'Chemistry', instructor: 'Dr. Marie Curie', max_capacity: 40, current_enrollment: 38, semester: 'Fall', year: 2024, status: 'Active', created_at: '2024-01-01', updated_at: '2024-01-15' },
  { id: 7, course_code: 'CHEM201', course_name: 'Organic Chemistry', description: 'Study of carbon compounds', credits: 4, department: 'Chemistry', instructor: 'Dr. Linus Pauling', max_capacity: 35, current_enrollment: 30, semester: 'Fall', year: 2024, status: 'Active', created_at: '2024-01-01', updated_at: '2024-01-15' },
  { id: 8, course_code: 'BIO101', course_name: 'Introduction to Biology', description: 'Fundamentals of living systems', credits: 4, department: 'Biology', instructor: 'Dr. Charles Darwin', max_capacity: 45, current_enrollment: 42, semester: 'Fall', year: 2024, status: 'Active', created_at: '2024-01-01', updated_at: '2024-01-15' },
  { id: 9, course_code: 'ENG101', course_name: 'English Composition', description: 'Writing and rhetoric fundamentals', credits: 3, department: 'English', instructor: 'Dr. William Shakespeare', max_capacity: 30, current_enrollment: 28, semester: 'Fall', year: 2024, status: 'Active', created_at: '2024-01-01', updated_at: '2024-01-15' },
  { id: 10, course_code: 'CS301', course_name: 'Database Systems', description: 'Relational database design and SQL', credits: 3, department: 'Computer Science', instructor: 'Dr. Edgar Codd', max_capacity: 35, current_enrollment: 25, semester: 'Spring', year: 2024, status: 'Completed', created_at: '2024-01-01', updated_at: '2024-05-15' },
];

// GET all courses with optional search and filter
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';
    const department = searchParams.get('department') || '';
    const status = searchParams.get('status') || '';
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');

    let query = 'SELECT * FROM courses WHERE 1=1';
    const params: (string | number)[] = [];

    if (search) {
      query += ' AND (course_name LIKE ? OR course_code LIKE ? OR instructor LIKE ?)';
      const searchPattern = `%${search}%`;
      params.push(searchPattern, searchPattern, searchPattern);
    }

    if (department) {
      query += ' AND department = ?';
      params.push(department);
    }

    if (status) {
      query += ' AND status = ?';
      params.push(status);
    }

    query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    params.push(limit, offset);

    const [rows] = await pool.execute<RowDataPacket[]>(query, params);

    // Get total count
    let countQuery = 'SELECT COUNT(*) as total FROM courses WHERE 1=1';
    const countParams: string[] = [];

    if (search) {
      countQuery += ' AND (course_name LIKE ? OR course_code LIKE ? OR instructor LIKE ?)';
      const searchPattern = `%${search}%`;
      countParams.push(searchPattern, searchPattern, searchPattern);
    }

    if (department) {
      countQuery += ' AND department = ?';
      countParams.push(department);
    }

    if (status) {
      countQuery += ' AND status = ?';
      countParams.push(status);
    }

    const [countResult] = await pool.execute<RowDataPacket[]>(countQuery, countParams);
    const total = countResult[0].total;

    // Get unique departments for filter
    const [departments] = await pool.execute<RowDataPacket[]>(
      'SELECT DISTINCT department FROM courses WHERE department IS NOT NULL'
    );

    return NextResponse.json({
      courses: rows,
      total,
      departments: departments.map((d) => d.department),
    });
  } catch (error) {
    console.error('Error fetching courses:', error);
    // Return mock data when database is not available
    let filtered = [...mockCourses];
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search')?.toLowerCase() || '';
    const department = searchParams.get('department') || '';
    const status = searchParams.get('status') || '';

    if (search) {
      filtered = filtered.filter(c => 
        c.course_name.toLowerCase().includes(search) ||
        c.course_code.toLowerCase().includes(search) ||
        c.instructor.toLowerCase().includes(search)
      );
    }
    if (department) {
      filtered = filtered.filter(c => c.department === department);
    }
    if (status) {
      filtered = filtered.filter(c => c.status === status);
    }

    const departments = [...new Set(mockCourses.map(c => c.department))];
    return NextResponse.json({ courses: filtered, total: filtered.length, departments });
  }
}

// POST create a new course
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      course_code,
      course_name,
      description,
      credits,
      department,
      instructor,
      max_capacity,
      semester,
      year,
      status,
    } = body;

    const query = `
      INSERT INTO courses (
        course_code, course_name, description, credits, department,
        instructor, max_capacity, semester, year, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const [result] = await pool.execute<ResultSetHeader>(query, [
      course_code,
      course_name,
      description || null,
      credits || 3,
      department || null,
      instructor || null,
      max_capacity || 30,
      semester || 'Fall',
      year || new Date().getFullYear(),
      status || 'Active',
    ]);

    return NextResponse.json(
      { message: 'Course created successfully', id: result.insertId },
      { status: 201 }
    );
  } catch (error) {
    console.error('Error creating course:', error);
    return NextResponse.json(
      { error: 'Database not connected. Please set up MySQL to add courses.' },
      { status: 500 }
    );
  }
}
