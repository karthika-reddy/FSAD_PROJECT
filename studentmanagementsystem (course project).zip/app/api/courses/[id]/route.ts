import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/db';
import { RowDataPacket, ResultSetHeader } from 'mysql2';

// GET single course by ID
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const [rows] = await pool.execute<RowDataPacket[]>(
      'SELECT * FROM courses WHERE id = ?',
      [id]
    );

    if (rows.length === 0) {
      return NextResponse.json(
        { error: 'Course not found' },
        { status: 404 }
      );
    }

    return NextResponse.json(rows[0]);
  } catch (error) {
    console.error('Error fetching course:', error);
    return NextResponse.json(
      { error: 'Database not connected. Please set up MySQL first.' },
      { status: 500 }
    );
  }
}

// PUT update course
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const {
      course_name,
      description,
      credits,
      department,
      instructor,
      max_capacity,
      semester,
      year,
      status,
    } = body;

    const query = `
      UPDATE courses SET
        course_name = ?, description = ?, credits = ?, department = ?,
        instructor = ?, max_capacity = ?, semester = ?, year = ?, status = ?
      WHERE id = ?
    `;

    const [result] = await pool.execute<ResultSetHeader>(query, [
      course_name,
      description || null,
      credits || 3,
      department || null,
      instructor || null,
      max_capacity || 30,
      semester || 'Fall',
      year || new Date().getFullYear(),
      status || 'Active',
      id,
    ]);

    if (result.affectedRows === 0) {
      return NextResponse.json(
        { error: 'Course not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({ message: 'Course updated successfully' });
  } catch (error) {
    console.error('Error updating course:', error);
    return NextResponse.json(
      { error: 'Database not connected. Please set up MySQL first.' },
      { status: 500 }
    );
  }
}

// DELETE course
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const [result] = await pool.execute<ResultSetHeader>(
      'DELETE FROM courses WHERE id = ?',
      [id]
    );

    if (result.affectedRows === 0) {
      return NextResponse.json(
        { error: 'Course not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({ message: 'Course deleted successfully' });
  } catch (error) {
    console.error('Error deleting course:', error);
    return NextResponse.json(
      { error: 'Database not connected. Please set up MySQL first.' },
      { status: 500 }
    );
  }
}
