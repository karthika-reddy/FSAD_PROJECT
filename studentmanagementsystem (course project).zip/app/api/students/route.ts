import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/db';
import { RowDataPacket, ResultSetHeader } from 'mysql2';

// Mock students data
const mockStudents = [
  { id: 1, student_id: 'STU001', first_name: 'John', last_name: 'Smith', email: 'john.smith@university.edu', phone: '555-0101', date_of_birth: '2000-05-15', gender: 'Male', address: '123 Main St', city: 'Boston', state: 'MA', zip_code: '02101', enrollment_date: '2022-09-01', status: 'Active', gpa: 3.75, created_at: '2022-09-01', updated_at: '2024-01-15' },
  { id: 2, student_id: 'STU002', first_name: 'Sarah', last_name: 'Johnson', email: 'sarah.johnson@university.edu', phone: '555-0102', date_of_birth: '2001-03-22', gender: 'Female', address: '456 Oak Ave', city: 'Cambridge', state: 'MA', zip_code: '02139', enrollment_date: '2022-09-01', status: 'Active', gpa: 3.98, created_at: '2022-09-01', updated_at: '2024-01-15' },
  { id: 3, student_id: 'STU003', first_name: 'Michael', last_name: 'Brown', email: 'michael.brown@university.edu', phone: '555-0103', date_of_birth: '2000-11-08', gender: 'Male', address: '789 Pine Rd', city: 'Somerville', state: 'MA', zip_code: '02143', enrollment_date: '2021-09-01', status: 'Active', gpa: 3.95, created_at: '2021-09-01', updated_at: '2024-01-15' },
  { id: 4, student_id: 'STU004', first_name: 'Emily', last_name: 'Davis', email: 'emily.davis@university.edu', phone: '555-0104', date_of_birth: '2001-07-30', gender: 'Female', address: '321 Elm St', city: 'Boston', state: 'MA', zip_code: '02102', enrollment_date: '2022-09-01', status: 'Active', gpa: 3.92, created_at: '2022-09-01', updated_at: '2024-01-15' },
  { id: 5, student_id: 'STU005', first_name: 'James', last_name: 'Wilson', email: 'james.wilson@university.edu', phone: '555-0105', date_of_birth: '2000-01-12', gender: 'Male', address: '654 Maple Dr', city: 'Cambridge', state: 'MA', zip_code: '02140', enrollment_date: '2021-09-01', status: 'Graduated', gpa: 3.80, created_at: '2021-09-01', updated_at: '2024-05-20' },
  { id: 6, student_id: 'STU006', first_name: 'Jessica', last_name: 'Martinez', email: 'jessica.martinez@university.edu', phone: '555-0106', date_of_birth: '2001-09-18', gender: 'Female', address: '987 Cedar Ln', city: 'Boston', state: 'MA', zip_code: '02103', enrollment_date: '2022-09-01', status: 'Active', gpa: 3.85, created_at: '2022-09-01', updated_at: '2024-01-15' },
  { id: 7, student_id: 'STU007', first_name: 'David', last_name: 'Garcia', email: 'david.garcia@university.edu', phone: '555-0107', date_of_birth: '2000-04-25', gender: 'Male', address: '147 Birch Ave', city: 'Somerville', state: 'MA', zip_code: '02144', enrollment_date: '2021-09-01', status: 'Active', gpa: 3.45, created_at: '2021-09-01', updated_at: '2024-01-15' },
  { id: 8, student_id: 'STU008', first_name: 'Ashley', last_name: 'Rodriguez', email: 'ashley.rodriguez@university.edu', phone: '555-0108', date_of_birth: '2001-12-03', gender: 'Female', address: '258 Walnut St', city: 'Boston', state: 'MA', zip_code: '02104', enrollment_date: '2022-09-01', status: 'Active', gpa: 3.62, created_at: '2022-09-01', updated_at: '2024-01-15' },
  { id: 9, student_id: 'STU009', first_name: 'Robert', last_name: 'Lee', email: 'robert.lee@university.edu', phone: '555-0109', date_of_birth: '2000-08-20', gender: 'Male', address: '369 Cherry Ct', city: 'Cambridge', state: 'MA', zip_code: '02141', enrollment_date: '2021-09-01', status: 'Inactive', gpa: 2.85, created_at: '2021-09-01', updated_at: '2024-01-15' },
  { id: 10, student_id: 'STU010', first_name: 'Amanda', last_name: 'Taylor', email: 'amanda.taylor@university.edu', phone: '555-0110', date_of_birth: '2001-02-14', gender: 'Female', address: '741 Spruce Way', city: 'Boston', state: 'MA', zip_code: '02105', enrollment_date: '2022-09-01', status: 'Active', gpa: 3.70, created_at: '2022-09-01', updated_at: '2024-01-15' },
];

// GET all students with optional search and filter
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';
    const status = searchParams.get('status') || '';
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');

    let query = 'SELECT * FROM students WHERE 1=1';
    const params: (string | number)[] = [];

    if (search) {
      query += ' AND (first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR student_id LIKE ?)';
      const searchPattern = `%${search}%`;
      params.push(searchPattern, searchPattern, searchPattern, searchPattern);
    }

    if (status) {
      query += ' AND status = ?';
      params.push(status);
    }

    query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    params.push(limit, offset);

    const [rows] = await pool.execute<RowDataPacket[]>(query, params);

    // Get total count for pagination
    let countQuery = 'SELECT COUNT(*) as total FROM students WHERE 1=1';
    const countParams: string[] = [];

    if (search) {
      countQuery += ' AND (first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR student_id LIKE ?)';
      const searchPattern = `%${search}%`;
      countParams.push(searchPattern, searchPattern, searchPattern, searchPattern);
    }

    if (status) {
      countQuery += ' AND status = ?';
      countParams.push(status);
    }

    const [countResult] = await pool.execute<RowDataPacket[]>(countQuery, countParams);
    const total = countResult[0].total;

    return NextResponse.json({ students: rows, total });
  } catch (error) {
    console.error('Error fetching students:', error);
    // Return mock data when database is not available
    let filtered = [...mockStudents];
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search')?.toLowerCase() || '';
    const status = searchParams.get('status') || '';

    if (search) {
      filtered = filtered.filter(s => 
        s.first_name.toLowerCase().includes(search) ||
        s.last_name.toLowerCase().includes(search) ||
        s.email.toLowerCase().includes(search) ||
        s.student_id.toLowerCase().includes(search)
      );
    }
    if (status) {
      filtered = filtered.filter(s => s.status === status);
    }

    return NextResponse.json({ students: filtered, total: filtered.length });
  }
}

// POST create a new student
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      student_id,
      first_name,
      last_name,
      email,
      phone,
      date_of_birth,
      gender,
      address,
      city,
      state,
      zip_code,
      status,
      gpa,
    } = body;

    const query = `
      INSERT INTO students (
        student_id, first_name, last_name, email, phone, date_of_birth,
        gender, address, city, state, zip_code, status, gpa
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const [result] = await pool.execute<ResultSetHeader>(query, [
      student_id,
      first_name,
      last_name,
      email,
      phone || null,
      date_of_birth || null,
      gender || 'Other',
      address || null,
      city || null,
      state || null,
      zip_code || null,
      status || 'Active',
      gpa || 0.0,
    ]);

    return NextResponse.json(
      { message: 'Student created successfully', id: result.insertId },
      { status: 201 }
    );
  } catch (error) {
    console.error('Error creating student:', error);
    return NextResponse.json(
      { error: 'Database not connected. Please set up MySQL to add students.' },
      { status: 500 }
    );
  }
}
