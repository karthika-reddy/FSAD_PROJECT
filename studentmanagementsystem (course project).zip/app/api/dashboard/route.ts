import { NextResponse } from 'next/server';
import pool from '@/lib/db';
import { RowDataPacket } from 'mysql2';

// Mock data for when database is not connected
const mockData = {
  totalStudents: 156,
  activeStudents: 142,
  totalCourses: 24,
  activeCourses: 18,
  totalEnrollments: 423,
  averageGpa: "3.42",
  statusDistribution: [
    { status: 'Active', count: 142 },
    { status: 'Inactive', count: 8 },
    { status: 'Graduated', count: 4 },
    { status: 'Suspended', count: 2 },
  ],
  departmentDistribution: [
    { department: 'Computer Science', count: 6 },
    { department: 'Mathematics', count: 4 },
    { department: 'Physics', count: 3 },
    { department: 'Chemistry', count: 3 },
    { department: 'Biology', count: 4 },
    { department: 'English', count: 4 },
  ],
  recentEnrollments: [
    { id: 1, student_name: 'John Smith', course_name: 'Data Structures', course_code: 'CS201', status: 'Enrolled', grade: null },
    { id: 2, student_name: 'Sarah Johnson', course_name: 'Calculus II', course_code: 'MATH201', status: 'Enrolled', grade: null },
    { id: 3, student_name: 'Michael Brown', course_name: 'Physics I', course_code: 'PHY101', status: 'Completed', grade: 'A' },
    { id: 4, student_name: 'Emily Davis', course_name: 'Organic Chemistry', course_code: 'CHEM201', status: 'Enrolled', grade: null },
    { id: 5, student_name: 'James Wilson', course_name: 'Introduction to Programming', course_code: 'CS101', status: 'Completed', grade: 'A-' },
  ],
  topStudents: [
    { id: 1, student_id: 'STU001', first_name: 'Sarah', last_name: 'Johnson', gpa: 3.98 },
    { id: 2, student_id: 'STU002', first_name: 'Michael', last_name: 'Brown', gpa: 3.95 },
    { id: 3, student_id: 'STU003', first_name: 'Emily', last_name: 'Davis', gpa: 3.92 },
    { id: 4, student_id: 'STU004', first_name: 'John', last_name: 'Smith', gpa: 3.88 },
    { id: 5, student_id: 'STU005', first_name: 'Jessica', last_name: 'Martinez', gpa: 3.85 },
  ],
  enrollmentStatusDistribution: [
    { status: 'Enrolled', count: 312 },
    { status: 'Completed', count: 98 },
    { status: 'Dropped', count: 8 },
    { status: 'Withdrawn', count: 5 },
  ],
};

export async function GET() {
  try {
    // Get total students
    const [totalStudentsResult] = await pool.execute<RowDataPacket[]>(
      'SELECT COUNT(*) as count FROM students'
    );
    const totalStudents = totalStudentsResult[0].count;

    // Get active students
    const [activeStudentsResult] = await pool.execute<RowDataPacket[]>(
      "SELECT COUNT(*) as count FROM students WHERE status = 'Active'"
    );
    const activeStudents = activeStudentsResult[0].count;

    // Get total courses
    const [totalCoursesResult] = await pool.execute<RowDataPacket[]>(
      'SELECT COUNT(*) as count FROM courses'
    );
    const totalCourses = totalCoursesResult[0].count;

    // Get active courses
    const [activeCoursesResult] = await pool.execute<RowDataPacket[]>(
      "SELECT COUNT(*) as count FROM courses WHERE status = 'Active'"
    );
    const activeCourses = activeCoursesResult[0].count;

    // Get total enrollments
    const [totalEnrollmentsResult] = await pool.execute<RowDataPacket[]>(
      'SELECT COUNT(*) as count FROM enrollments'
    );
    const totalEnrollments = totalEnrollmentsResult[0].count;

    // Get average GPA
    const [avgGpaResult] = await pool.execute<RowDataPacket[]>(
      'SELECT AVG(gpa) as avg_gpa FROM students WHERE gpa > 0'
    );
    const averageGpa = avgGpaResult[0].avg_gpa || 0;

    // Get student status distribution
    const [statusDistribution] = await pool.execute<RowDataPacket[]>(
      'SELECT status, COUNT(*) as count FROM students GROUP BY status'
    );

    // Get department distribution
    const [departmentDistribution] = await pool.execute<RowDataPacket[]>(
      'SELECT department, COUNT(*) as count FROM courses WHERE department IS NOT NULL GROUP BY department'
    );

    // Get recent enrollments
    const [recentEnrollments] = await pool.execute<RowDataPacket[]>(
      `SELECT 
        e.*,
        CONCAT(s.first_name, ' ', s.last_name) as student_name,
        c.course_name,
        c.course_code
      FROM enrollments e
      JOIN students s ON e.student_id = s.id
      JOIN courses c ON e.course_id = c.id
      ORDER BY e.created_at DESC
      LIMIT 5`
    );

    // Get top performing students
    const [topStudents] = await pool.execute<RowDataPacket[]>(
      `SELECT id, student_id, first_name, last_name, email, gpa, status 
       FROM students 
       WHERE gpa > 0 
       ORDER BY gpa DESC 
       LIMIT 5`
    );

    // Get enrollment status distribution
    const [enrollmentStatusDistribution] = await pool.execute<RowDataPacket[]>(
      'SELECT status, COUNT(*) as count FROM enrollments GROUP BY status'
    );

    return NextResponse.json({
      totalStudents,
      activeStudents,
      totalCourses,
      activeCourses,
      totalEnrollments,
      averageGpa: parseFloat(averageGpa).toFixed(2),
      statusDistribution,
      departmentDistribution,
      recentEnrollments,
      topStudents,
      enrollmentStatusDistribution,
    });
  } catch (error) {
    console.error('Error fetching dashboard data:', error);
    // Return mock data when database is not available
    return NextResponse.json(mockData);
  }
}
