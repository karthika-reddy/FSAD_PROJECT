import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/db';
import { RowDataPacket, ResultSetHeader } from 'mysql2';

// GET single enrollment by ID
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const [rows] = await pool.execute<RowDataPacket[]>(
      `SELECT 
        e.*,
        CONCAT(s.first_name, ' ', s.last_name) as student_name,
        c.course_name,
        c.course_code
      FROM enrollments e
      JOIN students s ON e.student_id = s.id
      JOIN courses c ON e.course_id = c.id
      WHERE e.id = ?`,
      [id]
    );

    if (rows.length === 0) {
      return NextResponse.json(
        { error: 'Enrollment not found' },
        { status: 404 }
      );
    }

    return NextResponse.json(rows[0]);
  } catch (error) {
    console.error('Error fetching enrollment:', error);
    return NextResponse.json(
      { error: 'Database not connected. Please set up MySQL first.' },
      { status: 500 }
    );
  }
}

// PUT update enrollment
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { grade, status, attendance_percentage } = body;

    const query = `
      UPDATE enrollments SET
        grade = ?, status = ?, attendance_percentage = ?
      WHERE id = ?
    `;

    const [result] = await pool.execute<ResultSetHeader>(query, [
      grade || null,
      status || 'Enrolled',
      attendance_percentage || 0,
      id,
    ]);

    if (result.affectedRows === 0) {
      return NextResponse.json(
        { error: 'Enrollment not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({ message: 'Enrollment updated successfully' });
  } catch (error) {
    console.error('Error updating enrollment:', error);
    return NextResponse.json(
      { error: 'Database not connected. Please set up MySQL first.' },
      { status: 500 }
    );
  }
}

// DELETE enrollment
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    // Get the course_id before deleting
    const [enrollment] = await pool.execute<RowDataPacket[]>(
      'SELECT course_id FROM enrollments WHERE id = ?',
      [id]
    );

    if (enrollment.length === 0) {
      return NextResponse.json(
        { error: 'Enrollment not found' },
        { status: 404 }
      );
    }

    const courseId = enrollment[0].course_id;

    const [result] = await pool.execute<ResultSetHeader>(
      'DELETE FROM enrollments WHERE id = ?',
      [id]
    );

    if (result.affectedRows > 0) {
      // Update course enrollment count
      await pool.execute(
        'UPDATE courses SET current_enrollment = GREATEST(current_enrollment - 1, 0) WHERE id = ?',
        [courseId]
      );
    }

    return NextResponse.json({ message: 'Enrollment deleted successfully' });
  } catch (error) {
    console.error('Error deleting enrollment:', error);
    return NextResponse.json(
      { error: 'Database not connected. Please set up MySQL first.' },
      { status: 500 }
    );
  }
}
