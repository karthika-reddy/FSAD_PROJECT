import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/db';
import { RowDataPacket, ResultSetHeader } from 'mysql2';

// Mock enrollments data
const mockEnrollments = [
  { id: 1, student_id: 1, course_id: 1, enrollment_date: '2024-09-01', grade: 'A', status: 'Enrolled', attendance_percentage: 95, student_name: 'John Smith', course_name: 'Introduction to Programming', course_code: 'CS101', created_at: '2024-09-01', updated_at: '2024-01-15' },
  { id: 2, student_id: 1, course_id: 3, enrollment_date: '2024-09-01', grade: 'A-', status: 'Enrolled', attendance_percentage: 92, student_name: 'John Smith', course_name: 'Calculus I', course_code: 'MATH101', created_at: '2024-09-01', updated_at: '2024-01-15' },
  { id: 3, student_id: 2, course_id: 2, enrollment_date: '2024-09-01', grade: 'A+', status: 'Enrolled', attendance_percentage: 98, student_name: 'Sarah Johnson', course_name: 'Data Structures', course_code: 'CS201', created_at: '2024-09-01', updated_at: '2024-01-15' },
  { id: 4, student_id: 2, course_id: 4, enrollment_date: '2024-09-01', grade: 'A', status: 'Enrolled', attendance_percentage: 96, student_name: 'Sarah Johnson', course_name: 'Calculus II', course_code: 'MATH201', created_at: '2024-09-01', updated_at: '2024-01-15' },
  { id: 5, student_id: 3, course_id: 5, enrollment_date: '2024-09-01', grade: 'A', status: 'Completed', attendance_percentage: 94, student_name: 'Michael Brown', course_name: 'Physics I', course_code: 'PHY101', created_at: '2024-09-01', updated_at: '2024-01-15' },
  { id: 6, student_id: 4, course_id: 7, enrollment_date: '2024-09-01', grade: null, status: 'Enrolled', attendance_percentage: 90, student_name: 'Emily Davis', course_name: 'Organic Chemistry', course_code: 'CHEM201', created_at: '2024-09-01', updated_at: '2024-01-15' },
  { id: 7, student_id: 5, course_id: 1, enrollment_date: '2023-09-01', grade: 'A-', status: 'Completed', attendance_percentage: 88, student_name: 'James Wilson', course_name: 'Introduction to Programming', course_code: 'CS101', created_at: '2023-09-01', updated_at: '2024-05-15' },
  { id: 8, student_id: 6, course_id: 8, enrollment_date: '2024-09-01', grade: 'B+', status: 'Enrolled', attendance_percentage: 85, student_name: 'Jessica Martinez', course_name: 'Introduction to Biology', course_code: 'BIO101', created_at: '2024-09-01', updated_at: '2024-01-15' },
  { id: 9, student_id: 7, course_id: 6, enrollment_date: '2024-09-01', grade: 'B', status: 'Enrolled', attendance_percentage: 82, student_name: 'David Garcia', course_name: 'General Chemistry', course_code: 'CHEM101', created_at: '2024-09-01', updated_at: '2024-01-15' },
  { id: 10, student_id: 8, course_id: 9, enrollment_date: '2024-09-01', grade: 'A-', status: 'Enrolled', attendance_percentage: 91, student_name: 'Ashley Rodriguez', course_name: 'English Composition', course_code: 'ENG101', created_at: '2024-09-01', updated_at: '2024-01-15' },
];

// GET all enrollments with student and course info
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const studentId = searchParams.get('student_id') || '';
    const courseId = searchParams.get('course_id') || '';
    const status = searchParams.get('status') || '';
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');

    let query = `
      SELECT 
        e.*,
        CONCAT(s.first_name, ' ', s.last_name) as student_name,
        s.student_id as student_code,
        c.course_name,
        c.course_code
      FROM enrollments e
      JOIN students s ON e.student_id = s.id
      JOIN courses c ON e.course_id = c.id
      WHERE 1=1
    `;
    const params: (string | number)[] = [];

    if (studentId) {
      query += ' AND e.student_id = ?';
      params.push(studentId);
    }

    if (courseId) {
      query += ' AND e.course_id = ?';
      params.push(courseId);
    }

    if (status) {
      query += ' AND e.status = ?';
      params.push(status);
    }

    query += ' ORDER BY e.created_at DESC LIMIT ? OFFSET ?';
    params.push(limit, offset);

    const [rows] = await pool.execute<RowDataPacket[]>(query, params);

    // Get total count
    let countQuery = `
      SELECT COUNT(*) as total FROM enrollments e WHERE 1=1
    `;
    const countParams: string[] = [];

    if (studentId) {
      countQuery += ' AND e.student_id = ?';
      countParams.push(studentId);
    }

    if (courseId) {
      countQuery += ' AND e.course_id = ?';
      countParams.push(courseId);
    }

    if (status) {
      countQuery += ' AND e.status = ?';
      countParams.push(status);
    }

    const [countResult] = await pool.execute<RowDataPacket[]>(countQuery, countParams);
    const total = countResult[0].total;

    return NextResponse.json({ enrollments: rows, total });
  } catch (error) {
    console.error('Error fetching enrollments:', error);
    // Return mock data when database is not available
    let filtered = [...mockEnrollments];
    const searchParams = request.nextUrl.searchParams;
    const status = searchParams.get('status') || '';

    if (status) {
      filtered = filtered.filter(e => e.status === status);
    }

    return NextResponse.json({ enrollments: filtered, total: filtered.length });
  }
}

// POST create a new enrollment
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { student_id, course_id, grade, status, attendance_percentage } = body;

    // Check if enrollment already exists
    const [existing] = await pool.execute<RowDataPacket[]>(
      'SELECT id FROM enrollments WHERE student_id = ? AND course_id = ?',
      [student_id, course_id]
    );

    if (existing.length > 0) {
      return NextResponse.json(
        { error: 'Student is already enrolled in this course' },
        { status: 400 }
      );
    }

    const query = `
      INSERT INTO enrollments (student_id, course_id, grade, status, attendance_percentage)
      VALUES (?, ?, ?, ?, ?)
    `;

    const [result] = await pool.execute<ResultSetHeader>(query, [
      student_id,
      course_id,
      grade || null,
      status || 'Enrolled',
      attendance_percentage || 0,
    ]);

    // Update course enrollment count
    await pool.execute(
      'UPDATE courses SET current_enrollment = current_enrollment + 1 WHERE id = ?',
      [course_id]
    );

    return NextResponse.json(
      { message: 'Enrollment created successfully', id: result.insertId },
      { status: 201 }
    );
  } catch (error) {
    console.error('Error creating enrollment:', error);
    return NextResponse.json(
      { error: 'Database not connected. Please set up MySQL to add enrollments.' },
      { status: 500 }
    );
  }
}
