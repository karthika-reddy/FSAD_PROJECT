"use client";

import { useState, useCallback } from "react";
import useSWR from "swr";
import { Sidebar } from "@/components/sidebar";
import { DataTable } from "@/components/data-table";
import { StatusBadge } from "@/components/status-badge";
import { StudentForm } from "@/components/student-form";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Plus, Users, MoreHorizontal, Pencil, Trash2, Eye } from "lucide-react";
import { Student } from "@/lib/db";

const fetcher = (url: string) => fetch(url).then((res) => res.json());

const ITEMS_PER_PAGE = 10;

export default function StudentsPage() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [deleteStudent, setDeleteStudent] = useState<Student | null>(null);
  const [viewStudent, setViewStudent] = useState<Student | null>(null);

  const { data, error, isLoading, mutate } = useSWR(
    `/api/students?search=${search}&status=${statusFilter === "all" ? "" : statusFilter}&limit=${ITEMS_PER_PAGE}&offset=${(currentPage - 1) * ITEMS_PER_PAGE}`,
    fetcher
  );

  const handleDelete = useCallback(async () => {
    if (!deleteStudent) return;

    try {
      await fetch(`/api/students/${deleteStudent.id}`, { method: "DELETE" });
      mutate();
      setDeleteStudent(null);
    } catch (error) {
      console.error("Error deleting student:", error);
    }
  }, [deleteStudent, mutate]);

  const handleEdit = useCallback((student: Student) => {
    setSelectedStudent(student);
    setIsFormOpen(true);
  }, []);

  const columns = [
    {
      key: "student_id",
      header: "Student ID",
      render: (student: Student) => (
        <span className="font-mono text-sm">{student.student_id}</span>
      ),
    },
    {
      key: "name",
      header: "Name",
      render: (student: Student) => (
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-sm font-semibold text-primary">
            {student.first_name[0]}
            {student.last_name[0]}
          </div>
          <div>
            <p className="font-medium">
              {student.first_name} {student.last_name}
            </p>
            <p className="text-sm text-muted-foreground">{student.email}</p>
          </div>
        </div>
      ),
    },
    {
      key: "phone",
      header: "Phone",
      render: (student: Student) => (
        <span className="text-muted-foreground">{student.phone || "N/A"}</span>
      ),
    },
    {
      key: "gpa",
      header: "GPA",
      render: (student: Student) => (
        <span className="font-semibold text-primary">
          {student.gpa?.toFixed(2) || "0.00"}
        </span>
      ),
    },
    {
      key: "status",
      header: "Status",
      render: (student: Student) => <StatusBadge status={student.status} />,
    },
    {
      key: "actions",
      header: "Actions",
      render: (student: Student) => (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => setViewStudent(student)}>
              <Eye className="mr-2 h-4 w-4" />
              View Details
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleEdit(student)}>
              <Pencil className="mr-2 h-4 w-4" />
              Edit
            </DropdownMenuItem>
            <DropdownMenuItem
              className="text-destructive"
              onClick={() => setDeleteStudent(student)}
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      ),
    },
  ];

  const totalPages = data ? Math.ceil(data.total / ITEMS_PER_PAGE) : 1;

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <main className="flex-1 lg:ml-64">
        <div className="p-4 pt-16 lg:p-8 lg:pt-8">
          <div className="space-y-6">
            {/* Header */}
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h1 className="text-3xl font-bold text-foreground">Students</h1>
                <p className="text-muted-foreground">
                  Manage your student records and information.
                </p>
              </div>
              <Button
                onClick={() => {
                  setSelectedStudent(null);
                  setIsFormOpen(true);
                }}
              >
                <Plus className="mr-2 h-4 w-4" />
                Add Student
              </Button>
            </div>

            {/* Stats */}
            <div className="grid gap-4 sm:grid-cols-4">
              <Card>
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                    <Users className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{data?.total || 0}</p>
                    <p className="text-sm text-muted-foreground">Total Students</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Table */}
            <Card>
              <CardHeader>
                <CardTitle>All Students</CardTitle>
              </CardHeader>
              <CardContent>
                {error ? (
                  <div className="py-8 text-center text-muted-foreground">
                    Failed to load students. Please check your database connection.
                  </div>
                ) : (
                  <DataTable
                    columns={columns}
                    data={data?.students || []}
                    searchPlaceholder="Search students..."
                    searchValue={search}
                    onSearchChange={(value) => {
                      setSearch(value);
                      setCurrentPage(1);
                    }}
                    filterOptions={[
                      {
                        label: "Status",
                        value: statusFilter,
                        options: [
                          { label: "All Status", value: "all" },
                          { label: "Active", value: "Active" },
                          { label: "Inactive", value: "Inactive" },
                          { label: "Graduated", value: "Graduated" },
                          { label: "Suspended", value: "Suspended" },
                        ],
                        onChange: (value) => {
                          setStatusFilter(value);
                          setCurrentPage(1);
                        },
                      },
                    ]}
                    pagination={{
                      currentPage,
                      totalPages,
                      onPageChange: setCurrentPage,
                    }}
                    isLoading={isLoading}
                    emptyMessage="No students found"
                  />
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Student Form Dialog */}
      <StudentForm
        open={isFormOpen}
        onOpenChange={setIsFormOpen}
        student={selectedStudent}
        onSuccess={() => mutate()}
      />

      {/* Delete Confirmation Dialog */}
      <AlertDialog
        open={!!deleteStudent}
        onOpenChange={() => setDeleteStudent(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Student</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete {deleteStudent?.first_name}{" "}
              {deleteStudent?.last_name}? This action cannot be undone and will
              also remove all associated enrollments.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* View Student Dialog */}
      <AlertDialog open={!!viewStudent} onOpenChange={() => setViewStudent(null)}>
        <AlertDialogContent className="max-w-lg">
          <AlertDialogHeader>
            <AlertDialogTitle>Student Details</AlertDialogTitle>
          </AlertDialogHeader>
          {viewStudent && (
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-2xl font-bold text-primary">
                  {viewStudent.first_name[0]}
                  {viewStudent.last_name[0]}
                </div>
                <div>
                  <p className="text-xl font-semibold">
                    {viewStudent.first_name} {viewStudent.last_name}
                  </p>
                  <p className="text-muted-foreground">{viewStudent.student_id}</p>
                </div>
              </div>
              <div className="grid gap-3 text-sm">
                <div className="flex justify-between border-b border-border pb-2">
                  <span className="text-muted-foreground">Email</span>
                  <span>{viewStudent.email}</span>
                </div>
                <div className="flex justify-between border-b border-border pb-2">
                  <span className="text-muted-foreground">Phone</span>
                  <span>{viewStudent.phone || "N/A"}</span>
                </div>
                <div className="flex justify-between border-b border-border pb-2">
                  <span className="text-muted-foreground">Gender</span>
                  <span>{viewStudent.gender}</span>
                </div>
                <div className="flex justify-between border-b border-border pb-2">
                  <span className="text-muted-foreground">Date of Birth</span>
                  <span>
                    {viewStudent.date_of_birth
                      ? new Date(viewStudent.date_of_birth).toLocaleDateString()
                      : "N/A"}
                  </span>
                </div>
                <div className="flex justify-between border-b border-border pb-2">
                  <span className="text-muted-foreground">Address</span>
                  <span className="text-right">
                    {viewStudent.address
                      ? `${viewStudent.address}, ${viewStudent.city}, ${viewStudent.state} ${viewStudent.zip_code}`
                      : "N/A"}
                  </span>
                </div>
                <div className="flex justify-between border-b border-border pb-2">
                  <span className="text-muted-foreground">GPA</span>
                  <span className="font-semibold text-primary">
                    {viewStudent.gpa?.toFixed(2) || "0.00"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Status</span>
                  <StatusBadge status={viewStudent.status} />
                </div>
              </div>
            </div>
          )}
          <AlertDialogFooter>
            <AlertDialogCancel>Close</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
