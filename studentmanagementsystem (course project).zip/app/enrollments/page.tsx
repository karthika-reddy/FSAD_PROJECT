"use client";

import { useState, useCallback } from "react";
import useSWR from "swr";
import { Sidebar } from "@/components/sidebar";
import { DataTable } from "@/components/data-table";
import { StatusBadge } from "@/components/status-badge";
import { EnrollmentForm } from "@/components/enrollment-form";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Plus, ClipboardList, MoreHorizontal, Pencil, Trash2, Eye } from "lucide-react";
import { Enrollment } from "@/lib/db";

const fetcher = (url: string) => fetch(url).then((res) => res.json());

const ITEMS_PER_PAGE = 10;

type EnrollmentWithDetails = Enrollment & {
  student_name: string;
  student_code: string;
  course_name: string;
  course_code: string;
};

export default function EnrollmentsPage() {
  const [statusFilter, setStatusFilter] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedEnrollment, setSelectedEnrollment] = useState<EnrollmentWithDetails | null>(null);
  const [deleteEnrollment, setDeleteEnrollment] = useState<EnrollmentWithDetails | null>(null);
  const [viewEnrollment, setViewEnrollment] = useState<EnrollmentWithDetails | null>(null);

  const { data, error, isLoading, mutate } = useSWR(
    `/api/enrollments?status=${statusFilter === "all" ? "" : statusFilter}&limit=${ITEMS_PER_PAGE}&offset=${(currentPage - 1) * ITEMS_PER_PAGE}`,
    fetcher
  );

  const handleDelete = useCallback(async () => {
    if (!deleteEnrollment) return;

    try {
      await fetch(`/api/enrollments/${deleteEnrollment.id}`, { method: "DELETE" });
      mutate();
      setDeleteEnrollment(null);
    } catch (error) {
      console.error("Error deleting enrollment:", error);
    }
  }, [deleteEnrollment, mutate]);

  const handleEdit = useCallback((enrollment: EnrollmentWithDetails) => {
    setSelectedEnrollment(enrollment);
    setIsFormOpen(true);
  }, []);

  const columns = [
    {
      key: "student",
      header: "Student",
      render: (enrollment: EnrollmentWithDetails) => (
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-sm font-semibold text-primary">
            {enrollment.student_name?.split(" ").map((n) => n[0]).join("") || "?"}
          </div>
          <div>
            <p className="font-medium">{enrollment.student_name}</p>
            <p className="text-sm text-muted-foreground font-mono">
              {enrollment.student_code}
            </p>
          </div>
        </div>
      ),
    },
    {
      key: "course",
      header: "Course",
      render: (enrollment: EnrollmentWithDetails) => (
        <div>
          <p className="font-medium">{enrollment.course_name}</p>
          <p className="text-sm text-primary font-mono">{enrollment.course_code}</p>
        </div>
      ),
    },
    {
      key: "grade",
      header: "Grade",
      render: (enrollment: EnrollmentWithDetails) => (
        <span
          className={`font-bold ${
            enrollment.grade?.startsWith("A")
              ? "text-primary"
              : enrollment.grade?.startsWith("B")
              ? "text-chart-2"
              : enrollment.grade?.startsWith("C")
              ? "text-chart-3"
              : enrollment.grade
              ? "text-destructive"
              : "text-muted-foreground"
          }`}
        >
          {enrollment.grade || "-"}
        </span>
      ),
    },
    {
      key: "attendance",
      header: "Attendance",
      render: (enrollment: EnrollmentWithDetails) => {
        const percentage = enrollment.attendance_percentage || 0;
        return (
          <div className="w-24 space-y-1">
            <div className="text-xs text-right">{percentage.toFixed(0)}%</div>
            <Progress
              value={percentage}
              className={`h-2 ${
                percentage >= 75
                  ? "[&>div]:bg-primary"
                  : percentage >= 50
                  ? "[&>div]:bg-chart-3"
                  : "[&>div]:bg-destructive"
              }`}
            />
          </div>
        );
      },
    },
    {
      key: "enrollment_date",
      header: "Enrolled On",
      render: (enrollment: EnrollmentWithDetails) => (
        <span className="text-muted-foreground">
          {enrollment.enrollment_date
            ? new Date(enrollment.enrollment_date).toLocaleDateString()
            : "N/A"}
        </span>
      ),
    },
    {
      key: "status",
      header: "Status",
      render: (enrollment: EnrollmentWithDetails) => (
        <StatusBadge status={enrollment.status} />
      ),
    },
    {
      key: "actions",
      header: "Actions",
      render: (enrollment: EnrollmentWithDetails) => (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => setViewEnrollment(enrollment)}>
              <Eye className="mr-2 h-4 w-4" />
              View Details
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleEdit(enrollment)}>
              <Pencil className="mr-2 h-4 w-4" />
              Edit
            </DropdownMenuItem>
            <DropdownMenuItem
              className="text-destructive"
              onClick={() => setDeleteEnrollment(enrollment)}
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      ),
    },
  ];

  const totalPages = data ? Math.ceil(data.total / ITEMS_PER_PAGE) : 1;

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <main className="flex-1 lg:ml-64">
        <div className="p-4 pt-16 lg:p-8 lg:pt-8">
          <div className="space-y-6">
            {/* Header */}
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h1 className="text-3xl font-bold text-foreground">Enrollments</h1>
                <p className="text-muted-foreground">
                  Manage student course enrollments and grades.
                </p>
              </div>
              <Button
                onClick={() => {
                  setSelectedEnrollment(null);
                  setIsFormOpen(true);
                }}
              >
                <Plus className="mr-2 h-4 w-4" />
                New Enrollment
              </Button>
            </div>

            {/* Stats */}
            <div className="grid gap-4 sm:grid-cols-4">
              <Card>
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                    <ClipboardList className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{data?.total || 0}</p>
                    <p className="text-sm text-muted-foreground">Total Enrollments</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Table */}
            <Card>
              <CardHeader>
                <CardTitle>All Enrollments</CardTitle>
              </CardHeader>
              <CardContent>
                {error ? (
                  <div className="py-8 text-center text-muted-foreground">
                    Failed to load enrollments. Please check your database connection.
                  </div>
                ) : (
                  <DataTable
                    columns={columns}
                    data={data?.enrollments || []}
                    filterOptions={[
                      {
                        label: "Status",
                        value: statusFilter,
                        options: [
                          { label: "All Status", value: "all" },
                          { label: "Enrolled", value: "Enrolled" },
                          { label: "Completed", value: "Completed" },
                          { label: "Dropped", value: "Dropped" },
                          { label: "Withdrawn", value: "Withdrawn" },
                        ],
                        onChange: (value) => {
                          setStatusFilter(value);
                          setCurrentPage(1);
                        },
                      },
                    ]}
                    pagination={{
                      currentPage,
                      totalPages,
                      onPageChange: setCurrentPage,
                    }}
                    isLoading={isLoading}
                    emptyMessage="No enrollments found"
                  />
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Enrollment Form Dialog */}
      <EnrollmentForm
        open={isFormOpen}
        onOpenChange={setIsFormOpen}
        enrollment={selectedEnrollment}
        onSuccess={() => mutate()}
      />

      {/* Delete Confirmation Dialog */}
      <AlertDialog
        open={!!deleteEnrollment}
        onOpenChange={() => setDeleteEnrollment(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Enrollment</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete the enrollment for{" "}
              {deleteEnrollment?.student_name} in {deleteEnrollment?.course_name}?
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* View Enrollment Dialog */}
      <AlertDialog
        open={!!viewEnrollment}
        onOpenChange={() => setViewEnrollment(null)}
      >
        <AlertDialogContent className="max-w-lg">
          <AlertDialogHeader>
            <AlertDialogTitle>Enrollment Details</AlertDialogTitle>
          </AlertDialogHeader>
          {viewEnrollment && (
            <div className="space-y-4">
              <div className="grid gap-3 text-sm">
                <div className="flex justify-between border-b border-border pb-2">
                  <span className="text-muted-foreground">Student</span>
                  <span className="font-medium">{viewEnrollment.student_name}</span>
                </div>
                <div className="flex justify-between border-b border-border pb-2">
                  <span className="text-muted-foreground">Student ID</span>
                  <span className="font-mono">{viewEnrollment.student_code}</span>
                </div>
                <div className="flex justify-between border-b border-border pb-2">
                  <span className="text-muted-foreground">Course</span>
                  <span className="font-medium">{viewEnrollment.course_name}</span>
                </div>
                <div className="flex justify-between border-b border-border pb-2">
                  <span className="text-muted-foreground">Course Code</span>
                  <span className="font-mono text-primary">
                    {viewEnrollment.course_code}
                  </span>
                </div>
                <div className="flex justify-between border-b border-border pb-2">
                  <span className="text-muted-foreground">Grade</span>
                  <span className="font-bold">
                    {viewEnrollment.grade || "Not Graded"}
                  </span>
                </div>
                <div className="flex justify-between border-b border-border pb-2">
                  <span className="text-muted-foreground">Attendance</span>
                  <span>{viewEnrollment.attendance_percentage?.toFixed(1)}%</span>
                </div>
                <div className="flex justify-between border-b border-border pb-2">
                  <span className="text-muted-foreground">Enrollment Date</span>
                  <span>
                    {viewEnrollment.enrollment_date
                      ? new Date(viewEnrollment.enrollment_date).toLocaleDateString()
                      : "N/A"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Status</span>
                  <StatusBadge status={viewEnrollment.status} />
                </div>
              </div>
            </div>
          )}
          <AlertDialogFooter>
            <AlertDialogCancel>Close</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
