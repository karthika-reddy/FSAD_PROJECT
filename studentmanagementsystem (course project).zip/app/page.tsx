import { Sidebar } from "@/components/sidebar";
import { Dashboard } from "@/components/dashboard";

export default function Home() {
  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <main className="flex-1 lg:ml-64">
        <div className="p-4 pt-16 lg:p-8 lg:pt-8">
          <Dashboard />
        </div>
      </main>
    </div>
  );
}
