"use client";

import { useState, useCallback } from "react";
import useSWR from "swr";
import { Sidebar } from "@/components/sidebar";
import { DataTable } from "@/components/data-table";
import { StatusBadge } from "@/components/status-badge";
import { CourseForm } from "@/components/course-form";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Plus, BookOpen, MoreHorizontal, Pencil, Trash2, Eye } from "lucide-react";
import { Course } from "@/lib/db";

const fetcher = (url: string) => fetch(url).then((res) => res.json());

const ITEMS_PER_PAGE = 10;

export default function CoursesPage() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [departmentFilter, setDepartmentFilter] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [deleteCourse, setDeleteCourse] = useState<Course | null>(null);
  const [viewCourse, setViewCourse] = useState<Course | null>(null);

  const { data, error, isLoading, mutate } = useSWR(
    `/api/courses?search=${search}&status=${statusFilter === "all" ? "" : statusFilter}&department=${departmentFilter === "all" ? "" : departmentFilter}&limit=${ITEMS_PER_PAGE}&offset=${(currentPage - 1) * ITEMS_PER_PAGE}`,
    fetcher
  );

  const handleDelete = useCallback(async () => {
    if (!deleteCourse) return;

    try {
      await fetch(`/api/courses/${deleteCourse.id}`, { method: "DELETE" });
      mutate();
      setDeleteCourse(null);
    } catch (error) {
      console.error("Error deleting course:", error);
    }
  }, [deleteCourse, mutate]);

  const handleEdit = useCallback((course: Course) => {
    setSelectedCourse(course);
    setIsFormOpen(true);
  }, []);

  const columns = [
    {
      key: "course_code",
      header: "Code",
      render: (course: Course) => (
        <span className="font-mono text-sm font-semibold text-primary">
          {course.course_code}
        </span>
      ),
    },
    {
      key: "course_name",
      header: "Course Name",
      render: (course: Course) => (
        <div>
          <p className="font-medium">{course.course_name}</p>
          <p className="text-sm text-muted-foreground">{course.department}</p>
        </div>
      ),
    },
    {
      key: "instructor",
      header: "Instructor",
      render: (course: Course) => (
        <span className="text-muted-foreground">
          {course.instructor || "TBA"}
        </span>
      ),
    },
    {
      key: "credits",
      header: "Credits",
      render: (course: Course) => (
        <span className="font-semibold">{course.credits}</span>
      ),
    },
    {
      key: "enrollment",
      header: "Enrollment",
      render: (course: Course) => {
        const percentage = (course.current_enrollment / course.max_capacity) * 100;
        return (
          <div className="w-32 space-y-1">
            <div className="flex justify-between text-xs">
              <span>{course.current_enrollment}/{course.max_capacity}</span>
              <span>{percentage.toFixed(0)}%</span>
            </div>
            <Progress value={percentage} className="h-2" />
          </div>
        );
      },
    },
    {
      key: "semester",
      header: "Semester",
      render: (course: Course) => (
        <span className="text-muted-foreground">
          {course.semester} {course.year}
        </span>
      ),
    },
    {
      key: "status",
      header: "Status",
      render: (course: Course) => <StatusBadge status={course.status} />,
    },
    {
      key: "actions",
      header: "Actions",
      render: (course: Course) => (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => setViewCourse(course)}>
              <Eye className="mr-2 h-4 w-4" />
              View Details
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleEdit(course)}>
              <Pencil className="mr-2 h-4 w-4" />
              Edit
            </DropdownMenuItem>
            <DropdownMenuItem
              className="text-destructive"
              onClick={() => setDeleteCourse(course)}
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      ),
    },
  ];

  const totalPages = data ? Math.ceil(data.total / ITEMS_PER_PAGE) : 1;

  const departmentOptions = [
    { label: "All Departments", value: "all" },
    ...(data?.departments?.map((d: string) => ({ label: d, value: d })) || []),
  ];

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <main className="flex-1 lg:ml-64">
        <div className="p-4 pt-16 lg:p-8 lg:pt-8">
          <div className="space-y-6">
            {/* Header */}
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h1 className="text-3xl font-bold text-foreground">Courses</h1>
                <p className="text-muted-foreground">
                  Manage course catalog and schedules.
                </p>
              </div>
              <Button
                onClick={() => {
                  setSelectedCourse(null);
                  setIsFormOpen(true);
                }}
              >
                <Plus className="mr-2 h-4 w-4" />
                Add Course
              </Button>
            </div>

            {/* Stats */}
            <div className="grid gap-4 sm:grid-cols-4">
              <Card>
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                    <BookOpen className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{data?.total || 0}</p>
                    <p className="text-sm text-muted-foreground">Total Courses</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Table */}
            <Card>
              <CardHeader>
                <CardTitle>All Courses</CardTitle>
              </CardHeader>
              <CardContent>
                {error ? (
                  <div className="py-8 text-center text-muted-foreground">
                    Failed to load courses. Please check your database connection.
                  </div>
                ) : (
                  <DataTable
                    columns={columns}
                    data={data?.courses || []}
                    searchPlaceholder="Search courses..."
                    searchValue={search}
                    onSearchChange={(value) => {
                      setSearch(value);
                      setCurrentPage(1);
                    }}
                    filterOptions={[
                      {
                        label: "Status",
                        value: statusFilter,
                        options: [
                          { label: "All Status", value: "all" },
                          { label: "Active", value: "Active" },
                          { label: "Inactive", value: "Inactive" },
                          { label: "Completed", value: "Completed" },
                        ],
                        onChange: (value) => {
                          setStatusFilter(value);
                          setCurrentPage(1);
                        },
                      },
                      {
                        label: "Department",
                        value: departmentFilter,
                        options: departmentOptions,
                        onChange: (value) => {
                          setDepartmentFilter(value);
                          setCurrentPage(1);
                        },
                      },
                    ]}
                    pagination={{
                      currentPage,
                      totalPages,
                      onPageChange: setCurrentPage,
                    }}
                    isLoading={isLoading}
                    emptyMessage="No courses found"
                  />
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Course Form Dialog */}
      <CourseForm
        open={isFormOpen}
        onOpenChange={setIsFormOpen}
        course={selectedCourse}
        onSuccess={() => mutate()}
      />

      {/* Delete Confirmation Dialog */}
      <AlertDialog
        open={!!deleteCourse}
        onOpenChange={() => setDeleteCourse(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Course</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete {deleteCourse?.course_code} -{" "}
              {deleteCourse?.course_name}? This action cannot be undone and will
              also remove all associated enrollments.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* View Course Dialog */}
      <AlertDialog open={!!viewCourse} onOpenChange={() => setViewCourse(null)}>
        <AlertDialogContent className="max-w-lg">
          <AlertDialogHeader>
            <AlertDialogTitle>Course Details</AlertDialogTitle>
          </AlertDialogHeader>
          {viewCourse && (
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="flex h-16 w-16 items-center justify-center rounded-lg bg-primary/10">
                  <BookOpen className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <p className="text-xl font-semibold">{viewCourse.course_name}</p>
                  <p className="font-mono text-primary">{viewCourse.course_code}</p>
                </div>
              </div>
              {viewCourse.description && (
                <p className="text-sm text-muted-foreground">
                  {viewCourse.description}
                </p>
              )}
              <div className="grid gap-3 text-sm">
                <div className="flex justify-between border-b border-border pb-2">
                  <span className="text-muted-foreground">Department</span>
                  <span>{viewCourse.department || "N/A"}</span>
                </div>
                <div className="flex justify-between border-b border-border pb-2">
                  <span className="text-muted-foreground">Instructor</span>
                  <span>{viewCourse.instructor || "TBA"}</span>
                </div>
                <div className="flex justify-between border-b border-border pb-2">
                  <span className="text-muted-foreground">Credits</span>
                  <span>{viewCourse.credits}</span>
                </div>
                <div className="flex justify-between border-b border-border pb-2">
                  <span className="text-muted-foreground">Capacity</span>
                  <span>
                    {viewCourse.current_enrollment} / {viewCourse.max_capacity}
                  </span>
                </div>
                <div className="flex justify-between border-b border-border pb-2">
                  <span className="text-muted-foreground">Semester</span>
                  <span>
                    {viewCourse.semester} {viewCourse.year}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Status</span>
                  <StatusBadge status={viewCourse.status} />
                </div>
              </div>
            </div>
          )}
          <AlertDialogFooter>
            <AlertDialogCancel>Close</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
