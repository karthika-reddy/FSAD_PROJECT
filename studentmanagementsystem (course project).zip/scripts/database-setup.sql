-- ============================================
-- STUDENT MANAGEMENT SYSTEM - DATABASE SETUP
-- ============================================
-- Run these commands in MySQL Command Line Client
-- 
-- Step 1: Login to MySQL
-- mysql -u root -p
-- Enter password: karthikareddy1*
--
-- Step 2: Copy and paste each section below
-- ============================================

-- Create the database
CREATE DATABASE IF NOT EXISTS student_management_system;

-- Use the database
USE student_management_system;

-- ============================================
-- TABLE 1: STUDENTS
-- ============================================
CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20) UNIQUE NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    date_of_birth DATE,
    gender ENUM('Male', 'Female', 'Other') DEFAULT 'Other',
    address TEXT,
    city VARCHAR(50),
    state VARCHAR(50),
    zip_code VARCHAR(20),
    enrollment_date DATE DEFAULT (CURRENT_DATE),
    status ENUM('Active', 'Inactive', 'Graduated', 'Suspended') DEFAULT 'Active',
    gpa DECIMAL(3, 2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ============================================
-- TABLE 2: COURSES
-- ============================================
CREATE TABLE IF NOT EXISTS courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(20) UNIQUE NOT NULL,
    course_name VARCHAR(100) NOT NULL,
    description TEXT,
    credits INT NOT NULL DEFAULT 3,
    department VARCHAR(50),
    instructor VARCHAR(100),
    max_capacity INT DEFAULT 30,
    current_enrollment INT DEFAULT 0,
    semester ENUM('Fall', 'Spring', 'Summer') DEFAULT 'Fall',
    year INT DEFAULT (YEAR(CURRENT_DATE)),
    status ENUM('Active', 'Inactive', 'Completed') DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ============================================
-- TABLE 3: ENROLLMENTS
-- ============================================
CREATE TABLE IF NOT EXISTS enrollments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    enrollment_date DATE DEFAULT (CURRENT_DATE),
    grade VARCHAR(2),
    status ENUM('Enrolled', 'Completed', 'Dropped', 'Withdrawn') DEFAULT 'Enrolled',
    attendance_percentage DECIMAL(5, 2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    UNIQUE KEY unique_enrollment (student_id, course_id)
);

-- ============================================
-- TABLE 4: ATTENDANCE (Optional - for real-time tracking)
-- ============================================
CREATE TABLE IF NOT EXISTS attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    attendance_date DATE NOT NULL,
    status ENUM('Present', 'Absent', 'Late', 'Excused') DEFAULT 'Present',
    remarks TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

-- ============================================
-- SAMPLE DATA - STUDENTS
-- ============================================
INSERT INTO students (student_id, first_name, last_name, email, phone, date_of_birth, gender, address, city, state, zip_code, status, gpa) VALUES
('STU001', 'John', 'Smith', 'john.smith@university.edu', '555-0101', '2000-05-15', 'Male', '123 Oak Street', 'New York', 'NY', '10001', 'Active', 3.75),
('STU002', 'Emily', 'Johnson', 'emily.johnson@university.edu', '555-0102', '2001-08-22', 'Female', '456 Maple Ave', 'Los Angeles', 'CA', '90001', 'Active', 3.92),
('STU003', 'Michael', 'Williams', 'michael.williams@university.edu', '555-0103', '1999-12-10', 'Male', '789 Pine Road', 'Chicago', 'IL', '60601', 'Active', 3.45),
('STU004', 'Sarah', 'Brown', 'sarah.brown@university.edu', '555-0104', '2000-03-28', 'Female', '321 Cedar Lane', 'Houston', 'TX', '77001', 'Active', 3.88),
('STU005', 'David', 'Davis', 'david.davis@university.edu', '555-0105', '2001-11-05', 'Male', '654 Birch Blvd', 'Phoenix', 'AZ', '85001', 'Inactive', 2.95),
('STU006', 'Jennifer', 'Miller', 'jennifer.miller@university.edu', '555-0106', '2000-07-19', 'Female', '987 Elm Street', 'Philadelphia', 'PA', '19101', 'Active', 3.67),
('STU007', 'James', 'Wilson', 'james.wilson@university.edu', '555-0107', '1999-09-03', 'Male', '147 Walnut Way', 'San Antonio', 'TX', '78201', 'Graduated', 3.82),
('STU008', 'Jessica', 'Moore', 'jessica.moore@university.edu', '555-0108', '2001-02-14', 'Female', '258 Cherry Circle', 'San Diego', 'CA', '92101', 'Active', 3.55),
('STU009', 'Robert', 'Taylor', 'robert.taylor@university.edu', '555-0109', '2000-06-30', 'Male', '369 Ash Avenue', 'Dallas', 'TX', '75201', 'Active', 3.20),
('STU010', 'Amanda', 'Anderson', 'amanda.anderson@university.edu', '555-0110', '2001-04-08', 'Female', '741 Spruce Street', 'San Jose', 'CA', '95101', 'Suspended', 2.45);

-- ============================================
-- SAMPLE DATA - COURSES
-- ============================================
INSERT INTO courses (course_code, course_name, description, credits, department, instructor, max_capacity, current_enrollment, semester, year, status) VALUES
('CS101', 'Introduction to Programming', 'Fundamental concepts of programming using Python', 4, 'Computer Science', 'Dr. Alan Turing', 35, 28, 'Fall', 2024, 'Active'),
('CS201', 'Data Structures', 'Arrays, linked lists, trees, and graphs', 4, 'Computer Science', 'Dr. Grace Hopper', 30, 25, 'Fall', 2024, 'Active'),
('CS301', 'Database Systems', 'Relational databases, SQL, and database design', 3, 'Computer Science', 'Dr. Edgar Codd', 30, 22, 'Fall', 2024, 'Active'),
('MATH101', 'Calculus I', 'Limits, derivatives, and integrals', 4, 'Mathematics', 'Dr. Isaac Newton', 40, 35, 'Fall', 2024, 'Active'),
('MATH201', 'Linear Algebra', 'Vectors, matrices, and linear transformations', 3, 'Mathematics', 'Dr. Carl Gauss', 35, 30, 'Fall', 2024, 'Active'),
('ENG101', 'English Composition', 'Academic writing and critical thinking', 3, 'English', 'Prof. Jane Austen', 25, 20, 'Fall', 2024, 'Active'),
('PHY101', 'Physics I', 'Mechanics, thermodynamics, and waves', 4, 'Physics', 'Dr. Albert Einstein', 30, 28, 'Fall', 2024, 'Active'),
('BIO101', 'Introduction to Biology', 'Cell biology, genetics, and evolution', 4, 'Biology', 'Dr. Charles Darwin', 35, 32, 'Fall', 2024, 'Active'),
('CHEM101', 'General Chemistry', 'Atomic structure, bonding, and reactions', 4, 'Chemistry', 'Dr. Marie Curie', 30, 27, 'Fall', 2024, 'Active'),
('HIST101', 'World History', 'Survey of world civilizations', 3, 'History', 'Prof. Howard Zinn', 40, 38, 'Fall', 2024, 'Active');

-- ============================================
-- SAMPLE DATA - ENROLLMENTS
-- ============================================
INSERT INTO enrollments (student_id, course_id, grade, status, attendance_percentage) VALUES
(1, 1, 'A', 'Enrolled', 95.00),
(1, 4, 'B+', 'Enrolled', 88.50),
(2, 1, 'A+', 'Enrolled', 100.00),
(2, 2, 'A', 'Enrolled', 96.00),
(2, 3, 'A-', 'Enrolled', 92.00),
(3, 2, 'B', 'Enrolled', 85.00),
(3, 5, 'B+', 'Enrolled', 87.50),
(4, 1, 'A', 'Enrolled', 98.00),
(4, 6, 'A-', 'Enrolled', 94.00),
(5, 7, 'C+', 'Dropped', 65.00),
(6, 3, 'A', 'Enrolled', 97.00),
(6, 8, 'B+', 'Enrolled', 89.00),
(7, 9, 'A', 'Completed', 99.00),
(8, 1, 'B+', 'Enrolled', 88.00),
(8, 10, 'A-', 'Enrolled', 93.00),
(9, 4, 'B', 'Enrolled', 82.00),
(9, 5, 'B-', 'Enrolled', 78.00),
(10, 6, 'D', 'Withdrawn', 45.00);

-- ============================================
-- SAMPLE DATA - ATTENDANCE
-- ============================================
INSERT INTO attendance (student_id, course_id, attendance_date, status, remarks) VALUES
(1, 1, '2024-01-15', 'Present', NULL),
(1, 1, '2024-01-17', 'Present', NULL),
(1, 1, '2024-01-19', 'Late', 'Arrived 10 minutes late'),
(2, 1, '2024-01-15', 'Present', NULL),
(2, 1, '2024-01-17', 'Present', NULL),
(2, 1, '2024-01-19', 'Present', NULL),
(3, 2, '2024-01-15', 'Present', NULL),
(3, 2, '2024-01-17', 'Absent', 'Medical leave'),
(4, 1, '2024-01-15', 'Present', NULL),
(4, 1, '2024-01-17', 'Present', NULL);

-- ============================================
-- USEFUL QUERIES FOR TESTING
-- ============================================

-- View all students
-- SELECT * FROM students;

-- View all courses
-- SELECT * FROM courses;

-- View enrollments with student and course names
-- SELECT 
--     e.id,
--     CONCAT(s.first_name, ' ', s.last_name) AS student_name,
--     c.course_name,
--     e.grade,
--     e.status
-- FROM enrollments e
-- JOIN students s ON e.student_id = s.id
-- JOIN courses c ON e.course_id = c.id;

-- Get enrollment count per course
-- SELECT 
--     c.course_name,
--     COUNT(e.id) AS enrollment_count
-- FROM courses c
-- LEFT JOIN enrollments e ON c.id = e.course_id
-- GROUP BY c.id;

-- ============================================
-- END OF SETUP SCRIPT
-- ============================================
