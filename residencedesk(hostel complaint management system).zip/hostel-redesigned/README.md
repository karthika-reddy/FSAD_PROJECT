# 🏠 Hostel Complaint System

A simple full-stack web application for managing hostel complaints.
Built with: HTML + CSS + JavaScript (Frontend) | Node.js + Express (Backend) | MySQL (Database)

---

## 📁 Project Structure

```
hostel-complaint-system/
├── database/
│   └── setup.sql          ← Run this first in MySQL
├── backend/
│   ├── server.js          ← Express API server
│   └── package.json       ← Node dependencies
├── frontend/
│   └── index.html         ← Complete frontend (open in browser)
└── README.md
```

---

## ⚙️ SETUP INSTRUCTIONS (Follow in order)

### STEP 1: Setup MySQL Database

Open MySQL Command Line Client and run:

```sql
-- Option A: Run the file directly
mysql -u root -p < database/setup.sql

-- Option B: Copy-paste into MySQL CLI
SOURCE C:/path/to/hostel-complaint-system/database/setup.sql;
```

This creates:
- Database: `hostel_complaints`
- Tables: `students`, `admins`, `complaints`
- Default Admin: `admin@hostel.com` / `admin123`
- Sample Student: `ravi@student.com` / `ravi123`

---

### STEP 2: Configure Database Password

Open `backend/server.js` and update line 11:

```js
password: '',   // ← Put your MySQL root password here
```

Example if your password is "mypass123":
```js
password: 'mypass123',
```

---

### STEP 3: Install Backend Dependencies

Open a terminal in VS Code:

```bash
cd backend
npm install
```

---

### STEP 4: Start the Backend Server

```bash
node server.js
```

You should see:
```
Server running on http://localhost:5000
Connected to MySQL database!
API Ready!
```

⚠️ Keep this terminal running!

---

### STEP 5: Open the Frontend

Simply open `frontend/index.html` in your browser.

You can:
- Double-click the file in VS Code Explorer
- Or right-click → Open with Live Server (if you have the VS Code extension)

---

## 🔐 Login Credentials

### Admin
- Email: `admin@hostel.com`
- Password: `admin123`

### Sample Student
- Email: `ravi@student.com`
- Password: `ravi123`

---

## ✅ Features

### Student Features
- Register new account
- Login / Logout
- Submit complaints (with categories)
- View all personal complaints with status

### Admin Features
- Login to admin panel
- View all complaints from all students
- Update complaint status (Pending → In Progress → Resolved)
- Add admin remarks to complaints
- View all registered students
- Dashboard with complaint statistics

---

## 🗂️ API Endpoints

| Method | URL | Description |
|--------|-----|-------------|
| POST | /api/student/register | Register student |
| POST | /api/student/login | Student login |
| POST | /api/complaints | Submit complaint |
| GET | /api/complaints/student/:id | Get student's complaints |
| POST | /api/admin/login | Admin login |
| GET | /api/admin/complaints | Get all complaints |
| PUT | /api/admin/complaints/:id | Update complaint |
| GET | /api/admin/students | Get all students |

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | HTML5, CSS3, Vanilla JavaScript |
| Backend | Node.js, Express.js |
| Database | MySQL |
| API | REST API |

---

## ❗ Common Errors & Fixes

**"Cannot connect to server"**
→ Backend is not running. Run `node server.js` in the backend folder.

**"Database connection failed"**
→ Wrong MySQL password in server.js or MySQL service not started.

**"ER_DUP_ENTRY"**
→ Email already registered. Use a different email.

**npm not found**
→ Install Node.js from https://nodejs.org

---

## 📝 Complaint Categories Available
- Plumbing
- Electricity
- Cleaning
- Wi-Fi / Internet
- Food / Mess
- Security
- Room Maintenance
- Other
