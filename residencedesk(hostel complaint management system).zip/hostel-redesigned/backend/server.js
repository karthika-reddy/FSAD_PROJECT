const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// =====================
// DATABASE CONNECTION
// =====================
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',        // Change to your MySQL username
  password: '',        // Change to your MySQL password
  database: 'hostel_complaints'
});

db.connect((err) => {
  if (err) {
    console.error('Database connection failed:', err.message);
    console.log('Make sure MySQL is running and you ran setup.sql');
    return;
  }
  console.log('Connected to MySQL database!');
});

// =====================
// STUDENT ROUTES
// =====================

// Student Register
app.post('/api/student/register', (req, res) => {
  const { name, email, password, room_number } = req.body;
  if (!name || !email || !password || !room_number) {
    return res.json({ success: false, message: 'All fields are required' });
  }
  const sql = 'INSERT INTO students (name, email, password, room_number) VALUES (?, ?, ?, ?)';
  db.query(sql, [name, email, password, room_number], (err, result) => {
    if (err) {
      if (err.code === 'ER_DUP_ENTRY') {
        return res.json({ success: false, message: 'Email already registered' });
      }
      return res.json({ success: false, message: 'Registration failed' });
    }
    res.json({ success: true, message: 'Registration successful! Please login.' });
  });
});

// Student Login
app.post('/api/student/login', (req, res) => {
  const { email, password } = req.body;
  const sql = 'SELECT * FROM students WHERE email = ? AND password = ?';
  db.query(sql, [email, password], (err, results) => {
    if (err) return res.json({ success: false, message: 'Login failed' });
    if (results.length === 0) {
      return res.json({ success: false, message: 'Invalid email or password' });
    }
    const student = results[0];
    res.json({
      success: true,
      message: 'Login successful',
      student: { id: student.id, name: student.name, email: student.email, room_number: student.room_number }
    });
  });
});

// Submit Complaint
app.post('/api/complaints', (req, res) => {
  const { student_id, category, description } = req.body;
  if (!student_id || !category || !description) {
    return res.json({ success: false, message: 'All fields are required' });
  }
  const sql = 'INSERT INTO complaints (student_id, category, description) VALUES (?, ?, ?)';
  db.query(sql, [student_id, category, description], (err, result) => {
    if (err) return res.json({ success: false, message: 'Failed to submit complaint' });
    res.json({ success: true, message: 'Complaint submitted successfully!' });
  });
});

// Get Student's Complaints
app.get('/api/complaints/student/:student_id', (req, res) => {
  const { student_id } = req.params;
  const sql = `SELECT c.*, s.name as student_name, s.room_number 
               FROM complaints c 
               JOIN students s ON c.student_id = s.id 
               WHERE c.student_id = ? 
               ORDER BY c.created_at DESC`;
  db.query(sql, [student_id], (err, results) => {
    if (err) return res.json({ success: false, message: 'Failed to fetch complaints' });
    res.json({ success: true, complaints: results });
  });
});

// =====================
// ADMIN ROUTES
// =====================

// Admin Login
app.post('/api/admin/login', (req, res) => {
  const { email, password } = req.body;
  const sql = 'SELECT * FROM admins WHERE email = ? AND password = ?';
  db.query(sql, [email, password], (err, results) => {
    if (err) return res.json({ success: false, message: 'Login failed' });
    if (results.length === 0) {
      return res.json({ success: false, message: 'Invalid admin credentials' });
    }
    const admin = results[0];
    res.json({
      success: true,
      message: 'Admin login successful',
      admin: { id: admin.id, name: admin.name, email: admin.email }
    });
  });
});

// Get All Complaints (Admin)
app.get('/api/admin/complaints', (req, res) => {
  const sql = `SELECT c.*, s.name as student_name, s.room_number 
               FROM complaints c 
               JOIN students s ON c.student_id = s.id 
               ORDER BY c.created_at DESC`;
  db.query(sql, (err, results) => {
    if (err) return res.json({ success: false, message: 'Failed to fetch complaints' });
    res.json({ success: true, complaints: results });
  });
});

// Update Complaint Status (Admin)
app.put('/api/admin/complaints/:id', (req, res) => {
  const { id } = req.params;
  const { status, admin_remark } = req.body;
  const sql = 'UPDATE complaints SET status = ?, admin_remark = ? WHERE id = ?';
  db.query(sql, [status, admin_remark, id], (err, result) => {
    if (err) return res.json({ success: false, message: 'Failed to update complaint' });
    res.json({ success: true, message: 'Complaint updated successfully!' });
  });
});

// Get All Students (Admin)
app.get('/api/admin/students', (req, res) => {
  const sql = 'SELECT id, name, email, room_number, created_at FROM students ORDER BY created_at DESC';
  db.query(sql, (err, results) => {
    if (err) return res.json({ success: false, message: 'Failed to fetch students' });
    res.json({ success: true, students: results });
  });
});

// =====================
// START SERVER
// =====================
const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
  console.log('API Ready!');
});
