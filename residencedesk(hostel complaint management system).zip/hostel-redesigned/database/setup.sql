-- ============================================
-- HOSTEL COMPLAINT SYSTEM - DATABASE SETUP
-- Run this in MySQL Command Line Client
-- Command: mysql -u root -p < setup.sql
-- ============================================

CREATE DATABASE IF NOT EXISTS hostel_complaints;
USE hostel_complaints;

-- Students Table
CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    room_number VARCHAR(10) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Admin Table
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL
);

-- Complaints Table
CREATE TABLE IF NOT EXISTS complaints (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    category VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    status ENUM('Pending', 'In Progress', 'Resolved') DEFAULT 'Pending',
    admin_remark VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id)
);

-- Insert default admin
INSERT INTO admins (name, email, password) VALUES 
('Hostel Admin', 'admin@hostel.com', 'admin123');

-- Insert sample student
INSERT INTO students (name, email, password, room_number) VALUES 
('Ravi Kumar', 'ravi@student.com', 'ravi123', 'A-101');

-- Insert sample complaints
INSERT INTO complaints (student_id, category, description, status) VALUES 
(1, 'Plumbing', 'Water leakage in bathroom since 2 days', 'Pending'),
(1, 'Electricity', 'Fan not working in room A-101', 'In Progress');

SELECT 'Database setup complete!' AS Message;
SELECT 'Tables created: students, admins, complaints' AS Info;
